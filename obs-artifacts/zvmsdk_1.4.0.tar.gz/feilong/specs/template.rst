================
Name of the spec
================

TODO: add your spec's name

Problem description
===================

What's the problem to be fixed?

Use Cases
---------

Who might use it and benefit?

Proposed change
===============

What's to be changed?

Alternatives
------------

If we don't do so ,do we have other choice?

API impact
----------

What kind of API change included?

DB impact
---------

Do we need change DB schema?

Security impact
---------------

Any thing related to security like RACF etc?

End user impact
---------------------

Any impact to end user?

Performance Impact
------------------

Performance benefit or potential issue?

Upper layer integration impact
------------------------------

Anything need to be changed in upper layer like openstack driver etc?

Upgrade impact
--------------

Any upgrade issue?

Implementation
==============

Assignee(s)
-----------

Who will work on it?

Work Items
----------

Some break down items on TODO.

Dependencies
============

Any special dependency?

Testing
=======

Any additional test need to be done, such as openstack 3rd party CI?

Documentation Impact
====================

Any document to be updated?
