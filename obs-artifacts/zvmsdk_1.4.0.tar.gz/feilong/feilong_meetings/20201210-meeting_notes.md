# 2020/12/10 Feilong project meeting

Start Time : Dec 10, 2020 05:24 AM

Meeting Recording:
https://zoom.us/rec/share/p4yfWdjYNz6zPyfaQdO6oS9pcvecvC-PgyU5LtDhydMAopxGhmd5ZPsW9Kuq2w18.IxY4wIAIUNtbxwrd

## Attendees

## Agenda topics
- Demonstration of the hosted second level z/VM developer environment
- Canceling the December 24 meeting

## Meeting Notes
- Michel Beaulieu
- Len Santalucia
- Vinnie Terrone
- Mike Friesenegger

### Demonstration of the hosted second level z/VM developer environment
- Access the recording using the link above to watch the demonstration
- Start at 1:27 and view until 28:39 in the recording

### Canceling the December 24 meeting
- The next meeting will be January 7, 2021

## Next meeting agenda topics
- Next steps with the developer environment
  - Create getting started documentation
    - How to access developer environment
    - Basic commands for dirmaint and feilong
