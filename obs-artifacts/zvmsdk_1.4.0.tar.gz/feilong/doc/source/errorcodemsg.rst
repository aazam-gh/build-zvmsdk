..
 Copyright Contributors to the Feilong Project.
 SPDX-License-Identifier: CC-BY-4.0

Error Codes and Messages
************************

This is a reference to Feilong API error codes
and messages.

.. csv-table::
   :header: "overallRC", "modID", "rc", "rs", "errmsg"
   :delim: ;
   :widths: 20,5,5,5,65
   :file: errcode.csv
